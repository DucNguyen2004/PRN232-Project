﻿namespace ProductWebAPI
{
    public class CategoryDTO
    {
        public string CategoryName { get; set; }
        public int NumProduct { get; set; }
    }
}
