﻿namespace FUNewsManagement
{
    public static class Constant
    {
        public static string LocalHost = "http://localhost:5272";
    }
}
